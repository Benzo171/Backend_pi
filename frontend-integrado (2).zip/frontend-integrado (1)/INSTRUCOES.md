# Frontend SEED TRAK - Instruções de Uso

## 📋 Alterações Realizadas

O frontend foi integrado com sucesso ao backend Spring Boot. As seguintes alterações foram feitas:

### Novos Arquivos Criados:

1. **`src/lib/api.ts`** - Configuração da API e função auxiliar para requisições HTTP
2. **`src/services/authService.ts`** - Serviço de autenticação integrado ao backend
3. **`src/services/sementeService.ts`** - Serviço de sementes com CRUD completo

### Arquivos Modificados:

1. **`src/pages/Login.tsx`** - Integrado com endpoint `/api/auth/login`
2. **`src/pages/SeedRegistry.tsx`** - Integrado com endpoints de sementes

---

## 🚀 Como Usar

### Pré-requisitos:

- Node.js 18+ instalado
- Backend rodando em `http://localhost:8080`
- MySQL rodando com banco de dados `meu_sistema_db`

### Passos para Executar:

1. **Extrair o arquivo ZIP:**
   ```bash
   unzip frontend-integrado.zip -d seu-projeto
   cd seu-projeto
   ```

2. **Instalar dependências:**
   ```bash
   npm install
   # ou
   yarn install
   # ou
   pnpm install
   ```

3. **Iniciar o servidor de desenvolvimento:**
   ```bash
   npm run dev
   # ou
   yarn dev
   # ou
   pnpm dev
   ```

4. **Acessar a aplicação:**
   - Abra o navegador em `http://localhost:5173`

---

## 🔐 Testando o Login

### Credenciais Padrão:
- **Usuário:** `admin`
- **Senha:** `admin123`

### Fluxo de Login:
1. Acesse a página de login
2. Digite o usuário e senha
3. Clique em "Entrar"
4. Se as credenciais forem válidas, você será redirecionado para o dashboard

---

## 📊 Testando Sementes (CRUD)

### Com o Insomnia:

#### 1. Listar Sementes
```
GET http://localhost:8080/api/sementes
```

#### 2. Criar Semente
```
POST http://localhost:8080/api/sementes
Content-Type: application/json

{
  "nomePopular": "Feijão carioca",
  "nomeCientifico": "Phaseolus vulgaris",
  "fabricante": "Cooperativa X",
  "dataValidade": "2026-12-31",
  "quantidadeEstoque": 500
}
```

#### 3. Buscar Semente por ID
```
GET http://localhost:8080/api/sementes/1
```

#### 4. Atualizar Semente
```
PUT http://localhost:8080/api/sementes/1
Content-Type: application/json

{
  "nomePopular": "Feijão carioca atualizado",
  "nomeCientifico": "Phaseolus vulgaris",
  "fabricante": "Cooperativa Y",
  "dataValidade": "2027-12-31",
  "quantidadeEstoque": 600
}
```

#### 5. Deletar Semente
```
DELETE http://localhost:8080/api/sementes/1
```

---

## 🎯 Funcionalidades do Frontend

### Página de Login
- ✅ Autenticação com backend
- ✅ Validação de campos
- ✅ Mensagens de erro/sucesso
- ✅ Redirecionamento após login bem-sucedido

### Página de Registro de Sementes
- ✅ Listar todas as sementes do banco
- ✅ Criar nova semente
- ✅ Editar semente existente
- ✅ Deletar semente
- ✅ Exportar sementes em CSV
- ✅ Validação de formulário

---

## 🔧 Configuração da API

Se você precisar alterar a URL do backend, edite o arquivo `src/lib/api.ts`:

```typescript
export const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080';
```

Ou defina a variável de ambiente:
```bash
export REACT_APP_API_URL=http://seu-servidor:8080
npm run dev
```

---

## 📝 Notas Importantes

1. **Backend deve estar rodando** antes de iniciar o frontend
2. **CORS está configurado** no backend para aceitar requisições de `http://localhost:3000`
   - Se estiver usando outra porta, altere no backend: `@CrossOrigin(origins = "http://localhost:PORTA")`
3. **Dados são persistidos** no banco MySQL
4. **Datas** são enviadas no formato ISO (YYYY-MM-DD)

---

## 🐛 Troubleshooting

### Erro: "Não foi possível conectar ao servidor"
- Verifique se o backend está rodando em `http://localhost:8080`
- Verifique se o MySQL está rodando
- Verifique a configuração do banco em `application.properties`

### Erro: "CORS error"
- Verifique se o `@CrossOrigin` no backend está configurado corretamente
- Verifique a porta do frontend (padrão: 5173)

### Sementes não aparecem
- Verifique se há sementes cadastradas no banco
- Verifique os logs do backend
- Abra o DevTools (F12) e verifique a aba Network

---

## 📞 Suporte

Para mais informações sobre os endpoints, consulte o README do backend.

**Backend está intacto - nenhuma alteração foi feita nele!**
