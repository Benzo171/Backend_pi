export interface Seed {
  id: string;
  nomePopular: string;
  nomeCientifico: string;
  fabricante: string;
  dataValidade: Date;
  quantidadeEstoque: number;
}

export type SeedFormType = Omit<Seed, "id">;
