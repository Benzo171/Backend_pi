import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Wifi, WifiOff, Battery, Thermometer, Wind, Droplets, CloudRain } from "lucide-react";

const sensorData = {
  online: 8,
  lowBattery: 2,
  offline: 0,
};

const weatherData = {
  temperature: 28,
  wind: 16,
  humidity: 44,
  rain: 0,
};

const harvestData = {
  total: 15.4,
  unit: "t/3m",
  crops: [
    { name: "Trigo", value: 6.4, color: "bg-success" },
    { name: "Milho", value: 3.2, color: "bg-success/80" },
    { name: "Tomate", value: 4.7, color: "bg-success/60" },
  ],
};

export default function Dashboard() {
  const maxCropValue = Math.max(...harvestData.crops.map((c) => c.value));

  return (
    <DashboardLayout>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Indicators */}
        <div className="space-y-6">
          {/* Sensors Card */}
          <div className="card-elevated p-6 animate-fade-in">
            <h2 className="text-lg font-bold text-foreground mb-6">Indicadores</h2>

            <div className="bg-muted/50 rounded-xl p-5 mb-4">
              <h3 className="text-sm font-semibold text-foreground mb-4">Sensores</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Wifi className="w-5 h-5 text-success" />
                  <div>
                    <p className="text-3xl font-bold text-foreground">{sensorData.online}</p>
                    <p className="text-xs text-muted-foreground">Online</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Battery className="w-5 h-5 text-warning" />
                  <div>
                    <p className="text-3xl font-bold text-foreground">{sensorData.lowBattery}</p>
                    <p className="text-xs text-muted-foreground">Bateria Baixa</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <WifiOff className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <p className="text-3xl font-bold text-foreground">{sensorData.offline}</p>
                    <p className="text-xs text-muted-foreground">Offline</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Weather Card */}
            <div className="bg-muted/50 rounded-xl p-5 mb-4">
              <h3 className="text-sm font-semibold text-foreground mb-4">Clima</h3>
              <div className="flex items-baseline gap-1 mb-4">
                <Thermometer className="w-5 h-5 text-primary" />
                <span className="text-4xl font-bold text-foreground">{weatherData.temperature}°C</span>
              </div>
              <div className="grid grid-cols-3 gap-3 text-sm">
                <div className="flex items-center gap-2">
                  <Wind className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">{weatherData.wind} km/h</span>
                </div>
                <div className="flex items-center gap-2">
                  <Droplets className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">{weatherData.humidity}%</span>
                </div>
                <div className="flex items-center gap-2">
                  <CloudRain className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">{weatherData.rain} mm</span>
                </div>
              </div>
            </div>

            {/* Harvest Card */}
            <div className="bg-muted/50 rounded-xl p-5">
              <h3 className="text-sm font-semibold text-foreground mb-4">Colheita</h3>
              <div className="flex items-baseline gap-2 mb-6">
                <span className="text-4xl font-bold text-foreground">{harvestData.total}</span>
                <span className="text-sm text-muted-foreground">{harvestData.unit}</span>
              </div>
              <div className="space-y-3">
                {harvestData.crops.map((crop) => (
                  <div key={crop.name} className="flex items-center gap-3">
                    <span className="text-sm text-muted-foreground w-16">{crop.name}</span>
                    <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className={`h-full ${crop.color} rounded-full transition-all duration-500`}
                        style={{ width: `${(crop.value / maxCropValue) * 100}%` }}
                      />
                    </div>
                    <span className="text-sm font-medium text-foreground w-10 text-right">
                      {crop.value}t
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Map Placeholder */}
        <div className="lg:col-span-2">
          <div className="card-elevated h-full min-h-[500px] flex items-center justify-center animate-fade-in" style={{ animationDelay: "0.1s" }}>
            <div className="text-center text-muted-foreground">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
                <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                </svg>
              </div>
              <p className="text-sm font-medium">Mapa de Campos</p>
              <p className="text-xs mt-1">Visualização geográfica dos campos</p>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
