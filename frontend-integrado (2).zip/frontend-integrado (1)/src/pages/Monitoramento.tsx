import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Wifi, WifiOff, Battery, AlertTriangle, CheckCircle2, Thermometer, Droplets, Sun } from "lucide-react";
import { cn } from "@/lib/utils";

interface Sensor {
  id: string;
  nome: string;
  campo: string;
  status: "online" | "offline" | "bateria_baixa";
  temperatura: number;
  umidade: number;
  luminosidade: number;
  ultimaLeitura: string;
}

const sensores: Sensor[] = [
  {
    id: "S001",
    nome: "Sensor Alpha",
    campo: "Campo 01",
    status: "online",
    temperatura: 28,
    umidade: 65,
    luminosidade: 85,
    ultimaLeitura: "há 2 min",
  },
  {
    id: "S002",
    nome: "Sensor Beta",
    campo: "Campo 01",
    status: "online",
    temperatura: 27,
    umidade: 68,
    luminosidade: 82,
    ultimaLeitura: "há 3 min",
  },
  {
    id: "S003",
    nome: "Sensor Gamma",
    campo: "Campo 02",
    status: "bateria_baixa",
    temperatura: 29,
    umidade: 62,
    luminosidade: 90,
    ultimaLeitura: "há 5 min",
  },
  {
    id: "S004",
    nome: "Sensor Delta",
    campo: "Campo 02",
    status: "online",
    temperatura: 26,
    umidade: 70,
    luminosidade: 78,
    ultimaLeitura: "há 1 min",
  },
  {
    id: "S005",
    nome: "Sensor Epsilon",
    campo: "Campo 03",
    status: "bateria_baixa",
    temperatura: 30,
    umidade: 58,
    luminosidade: 92,
    ultimaLeitura: "há 8 min",
  },
  {
    id: "S006",
    nome: "Sensor Zeta",
    campo: "Campo 04",
    status: "online",
    temperatura: 25,
    umidade: 72,
    luminosidade: 75,
    ultimaLeitura: "há 2 min",
  },
];

const statusConfig = {
  online: {
    label: "Online",
    icon: Wifi,
    className: "bg-success/10 text-success",
  },
  offline: {
    label: "Offline",
    icon: WifiOff,
    className: "bg-muted text-muted-foreground",
  },
  bateria_baixa: {
    label: "Bateria Baixa",
    icon: Battery,
    className: "bg-warning/10 text-warning",
  },
};

export default function Monitoramento() {
  const onlineCount = sensores.filter((s) => s.status === "online").length;
  const alertCount = sensores.filter((s) => s.status === "bateria_baixa").length;
  const offlineCount = sensores.filter((s) => s.status === "offline").length;

  return (
    <DashboardLayout>
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="card-elevated p-5 flex items-center gap-4 animate-fade-in">
          <div className="w-12 h-12 rounded-xl bg-success/10 flex items-center justify-center">
            <CheckCircle2 className="w-6 h-6 text-success" />
          </div>
          <div>
            <p className="text-3xl font-bold text-foreground">{onlineCount}</p>
            <p className="text-sm text-muted-foreground">Sensores Online</p>
          </div>
        </div>

        <div className="card-elevated p-5 flex items-center gap-4 animate-fade-in" style={{ animationDelay: "0.1s" }}>
          <div className="w-12 h-12 rounded-xl bg-warning/10 flex items-center justify-center">
            <AlertTriangle className="w-6 h-6 text-warning" />
          </div>
          <div>
            <p className="text-3xl font-bold text-foreground">{alertCount}</p>
            <p className="text-sm text-muted-foreground">Alertas</p>
          </div>
        </div>

        <div className="card-elevated p-5 flex items-center gap-4 animate-fade-in" style={{ animationDelay: "0.2s" }}>
          <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center">
            <WifiOff className="w-6 h-6 text-muted-foreground" />
          </div>
          <div>
            <p className="text-3xl font-bold text-foreground">{offlineCount}</p>
            <p className="text-sm text-muted-foreground">Offline</p>
          </div>
        </div>
      </div>

      {/* Sensors Grid */}
      <div className="card-elevated p-6 md:p-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-foreground">Monitoramento de Sensores</h1>
          <button className="text-sm text-primary font-medium hover:underline">
            + Adicionar Sensor
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {sensores.map((sensor, index) => {
            const StatusIcon = statusConfig[sensor.status].icon;
            
            return (
              <div
                key={sensor.id}
                className="bg-card border border-border/50 rounded-2xl p-5 hover:shadow-soft transition-all duration-300 cursor-pointer animate-fade-in"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-bold text-foreground">{sensor.nome}</h3>
                    <p className="text-xs text-muted-foreground">{sensor.campo}</p>
                  </div>
                  <span
                    className={cn(
                      "px-2.5 py-1 rounded-full text-xs font-medium flex items-center gap-1.5",
                      statusConfig[sensor.status].className
                    )}
                  >
                    <StatusIcon className="w-3.5 h-3.5" />
                    {statusConfig[sensor.status].label}
                  </span>
                </div>

                {/* Readings */}
                <div className="grid grid-cols-3 gap-3 mb-4">
                  <div className="text-center">
                    <div className="w-10 h-10 mx-auto rounded-lg bg-muted flex items-center justify-center mb-1">
                      <Thermometer className="w-5 h-5 text-pending" />
                    </div>
                    <p className="text-lg font-bold text-foreground">{sensor.temperatura}°</p>
                    <p className="text-xs text-muted-foreground">Temp</p>
                  </div>
                  <div className="text-center">
                    <div className="w-10 h-10 mx-auto rounded-lg bg-muted flex items-center justify-center mb-1">
                      <Droplets className="w-5 h-5 text-primary" />
                    </div>
                    <p className="text-lg font-bold text-foreground">{sensor.umidade}%</p>
                    <p className="text-xs text-muted-foreground">Umid</p>
                  </div>
                  <div className="text-center">
                    <div className="w-10 h-10 mx-auto rounded-lg bg-muted flex items-center justify-center mb-1">
                      <Sun className="w-5 h-5 text-warning" />
                    </div>
                    <p className="text-lg font-bold text-foreground">{sensor.luminosidade}%</p>
                    <p className="text-xs text-muted-foreground">Luz</p>
                  </div>
                </div>

                {/* Footer */}
                <p className="text-xs text-muted-foreground text-center">
                  Última leitura: {sensor.ultimaLeitura}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </DashboardLayout>
  );
}
