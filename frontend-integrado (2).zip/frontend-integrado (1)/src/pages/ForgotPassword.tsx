import { useState } from "react";
import { Link } from "react-router-dom";
import { AuthLayout } from "@/components/layout/AuthLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Mail, Phone, ArrowLeft } from "lucide-react";

type RecoveryMethod = "email" | "sms";

export default function ForgotPassword() {
  const [method, setMethod] = useState<RecoveryMethod>("email");
  const [value, setValue] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle password recovery
  };

  return (
    <AuthLayout>
      <Link
        to="/login"
        className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-8"
      >
        <ArrowLeft className="w-4 h-4" />
        <span className="text-sm">Voltar</span>
      </Link>

      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-foreground mb-2">Esqueci a senha</h1>
        <p className="text-muted-foreground">
          Enviaremos um código para recuperar sua senha
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="relative">
          {method === "email" ? (
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground/50" />
          ) : (
            <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground/50" />
          )}
          <Input
            type={method === "email" ? "email" : "tel"}
            placeholder={method === "email" ? "Email" : "Telefone"}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            className="pl-12"
          />
        </div>

        <p className="text-center text-sm text-muted-foreground">
          Enviar por{" "}
          <button
            type="button"
            onClick={() => {
              setMethod(method === "email" ? "sms" : "email");
              setValue("");
            }}
            className="text-accent font-semibold hover:underline"
          >
            {method === "email" ? "SMS" : "E-mail"}
          </button>
        </p>

        <Button type="submit" className="w-full" size="lg">
          Enviar
        </Button>
      </form>
    </AuthLayout>
  );
}
