import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Camera, ChevronDown, User } from "lucide-react";

const profileData = {
  nome: "Adamastor Frederico Nunes de Melo",
  profissao: "Fazendeiro e Agricultor",
  endereco: {
    estado: "Góias (GO)",
    regiao: "Chapada dos Veadeiros",
    cidade: "Alto Paraíso de Goiás",
    cep: "73770-000",
    numero: "1567",
    complemento: "(Complemento)",
    lote: "nº 1023-01",
  },
};

interface FieldProps {
  label?: string;
  value: string;
  isLarge?: boolean;
}

function ProfileField({ value, isLarge = false }: FieldProps) {
  return (
    <div className={`bg-success/20 rounded-xl px-4 py-3.5 flex items-center justify-between ${isLarge ? 'col-span-2' : ''}`}>
      <span className="text-foreground font-medium">{value}</span>
      <ChevronDown className="w-5 h-5 text-primary" />
    </div>
  );
}

export default function Perfil() {
  return (
    <DashboardLayout>
      <div className="card-elevated p-6 md:p-8 max-w-4xl mx-auto animate-fade-in">
        <h1 className="text-2xl font-bold text-foreground text-center mb-8">Perfil</h1>

        {/* Avatar Section */}
        <div className="flex flex-col md:flex-row items-center gap-8 mb-8">
          <div className="relative">
            <div className="w-32 h-32 rounded-full bg-muted flex items-center justify-center">
              <User className="w-16 h-16 text-muted-foreground" />
            </div>
            <button className="absolute bottom-0 right-0 w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground shadow-lg hover:bg-primary/90 transition-colors">
              <Camera className="w-5 h-5" />
            </button>
          </div>

          <div className="flex-1 w-full space-y-3">
            <ProfileField value={profileData.nome} isLarge />
            <ProfileField value={profileData.profissao} isLarge />
          </div>
        </div>

        {/* Address Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <ProfileField value={profileData.endereco.estado} />
          <ProfileField value={profileData.endereco.regiao} />
          <ProfileField value={profileData.endereco.cidade} />
          <ProfileField value={profileData.endereco.cep} />
          <ProfileField value={profileData.endereco.numero} />
          <ProfileField value={profileData.endereco.complemento} />
          <ProfileField value={profileData.endereco.lote} />
        </div>

        {/* Actions */}
        <div className="flex justify-center gap-4 mt-10">
          <button className="px-8 py-3 rounded-xl border-2 border-primary text-primary font-semibold hover:bg-primary hover:text-primary-foreground transition-all">
            Cancelar
          </button>
          <button className="px-8 py-3 rounded-xl bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-all">
            Salvar Alterações
          </button>
        </div>
      </div>
    </DashboardLayout>
  );
}
