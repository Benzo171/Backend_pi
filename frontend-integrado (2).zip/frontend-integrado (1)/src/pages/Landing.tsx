import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowUpRight } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-card">
      {/* Header */}
      <header className="flex items-center justify-between px-6 md:px-12 py-6">
        <Link to="/" className="flex flex-col leading-tight">
          <span className="text-accent font-bold text-lg tracking-tight">SEED</span>
          <span className="text-foreground font-bold text-lg tracking-tight -mt-1">TRAK</span>
        </Link>

        <div className="flex items-center gap-3">

          <Link to="/login">
            <Button variant="accent" size="sm">
              Entrar
            </Button>
          </Link>
        </div>
      </header>

      {/* Hero */}
      <main className="px-6 md:px-12 py-8 md:py-16">
        <div className="max-w-7xl mx-auto">
          {/* Hero Text */}
          <div className="max-w-lg mb-10 animate-fade-in">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight italic">
              Conectamos produtores ao futuro da agricultura, entregando sementes com rapidez, qualidade e confiança.
            </h1>
          </div>

          {/* Hero Image */}
          <div className="relative rounded-3xl overflow-hidden animate-slide-up" style={{ animationDelay: "0.2s" }}>
            <img
              src="https://images.unsplash.com/photo-1625246333195-78d9c38ad449?q=80&w=2070&auto=format&fit=crop"
              alt="Trabalhadores em campo agrícola"
              className="w-full h-[400px] md:h-[500px] lg:h-[600px] object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
            
            {/* CTA Button on Image */}
            <Link
              to="/login"
              className="absolute top-6 right-6 w-14 h-14 rounded-full bg-card flex items-center justify-center shadow-elevated hover:scale-105 transition-transform"
            >
              <ArrowUpRight className="w-6 h-6 text-foreground" />
            </Link>
          </div>

          {/* Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16 animate-fade-in" style={{ animationDelay: "0.4s" }}>
            <div className="text-center md:text-left">
              <div className="w-12 h-12 rounded-xl bg-success/10 flex items-center justify-center mb-4 mx-auto md:mx-0">
                <svg className="w-6 h-6 text-success" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="font-bold text-foreground mb-2">Qualidade Garantida</h3>
              <p className="text-sm text-muted-foreground">Sementes certificadas com alto índice de germinação</p>
            </div>
            <div className="text-center md:text-left">
              <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-4 mx-auto md:mx-0">
                <svg className="w-6 h-6 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="font-bold text-foreground mb-2">Entrega Rápida</h3>
              <p className="text-sm text-muted-foreground">Logística otimizada para chegada em tempo hábil</p>
            </div>
            <div className="text-center md:text-left">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 mx-auto md:mx-0">
                <svg className="w-6 h-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
              <h3 className="font-bold text-foreground mb-2">Monitoramento</h3>
              <p className="text-sm text-muted-foreground">Acompanhe seus campos e entregas em tempo real</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
