import { useState, useEffect } from "react";
import { format } from "date-fns";
import { Sprout } from "lucide-react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { SeedForm } from "@/components/SeedForm";
import { SeedTable } from "@/components/SeedTable";
import { Seed } from "@/types/seed";
import { toast } from "@/components/ui/use-toast";
import { sementeService } from "@/services/sementeService";

const SeedRegistry = () => {
  const [seeds, setSeeds] = useState<Seed[]>([]);
  const [editingSeed, setEditingSeed] = useState<Seed | null>(null);
  const [loading, setLoading] = useState(true);

  // Carregar sementes ao montar o componente
  useEffect(() => {
    loadSeeds();
  }, []);

  const loadSeeds = async () => {
    try {
      setLoading(true);
      const data = await sementeService.listar();
      const seeds = data.map(dto => sementeService.dtoToSeed(dto));
      setSeeds(seeds);
    } catch (error) {
      console.error("Erro ao carregar sementes:", error);
      toast({
        title: "Erro ao carregar sementes",
        description: error instanceof Error 
          ? error.message 
          : "Não foi possível carregar as sementes do servidor",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (seedData: Omit<Seed, "id">) => {
    try {
      const dto = sementeService.seedToDTO(seedData);

      if (editingSeed) {
        // Update existing seed
        const seedId = parseInt(editingSeed.id);
        await sementeService.atualizar(seedId, dto);
        
        setSeeds(seeds.map(s => 
          s.id === editingSeed.id 
            ? { ...seedData, id: editingSeed.id } 
            : s
        ));
        
        toast({
          title: "Semente atualizada com sucesso",
          description: `"${seedData.nomePopular}" foi atualizada no sistema.`,
        });
        setEditingSeed(null);
      } else {
        // Add new seed
        const created = await sementeService.criar(dto);
        const newSeed = sementeService.dtoToSeed(created);
        setSeeds([...seeds, newSeed]);
        
        toast({
          title: "Semente cadastrada com sucesso",
          description: `"${seedData.nomePopular}" foi adicionada ao sistema.`,
        });
      }
    } catch (error) {
      console.error("Erro ao salvar semente:", error);
      toast({
        title: "Erro ao salvar semente",
        description: error instanceof Error 
          ? error.message 
          : "Não foi possível salvar a semente",
        variant: "destructive",
      });
    }
  };

  const handleCancel = () => {
    setEditingSeed(null);
  };

  const handleEdit = (seed: Seed) => {
    setEditingSeed(seed);
    // Scroll to form
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleExport = () => {
    if (seeds.length === 0) {
      toast({
        title: "Nenhuma semente para exportar",
        description: "Adicione sementes antes de exportar.",
        variant: "destructive",
      });
      return;
    }

    const headers = [
      "ID",
      "Nome Popular",
      "Nome Científico",
      "Fabricante",
      "Data de Validade",
      "Quantidade em Estoque",
    ];

    const csvContent = [
      headers.join(";"),
      ...seeds.map((seed) =>
        [
          seed.id,
          `"${seed.nomePopular.replace(/"/g, '""')}"`,
          `"${seed.nomeCientifico.replace(/"/g, '""')}"`,
          `"${seed.fabricante.replace(/"/g, '""')}"`,
          format(new Date(seed.dataValidade), "dd/MM/yyyy"),
          seed.quantidadeEstoque,
        ].join(";")
      ),
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "registro_sementes.csv");
    link.click();

    toast({
      title: "Exportação concluída",
      description: "O arquivo CSV foi baixado com sucesso.",
    });
  };

  const handleDelete = async (id: string) => {
    try {
      const seedToDelete = seeds.find(s => s.id === id);
      const seedId = parseInt(id);
      
      await sementeService.deletar(seedId);
      
      setSeeds(seeds.filter(s => s.id !== id));
      if (editingSeed?.id === id) {
        setEditingSeed(null);
      }
      
      toast({
        title: "Semente removida",
        description: seedToDelete 
          ? `"${seedToDelete.nomePopular}" foi removida do sistema.`
          : "A semente foi removida do sistema.",
        variant: "destructive",
      });
    } catch (error) {
      console.error("Erro ao deletar semente:", error);
      toast({
        title: "Erro ao deletar semente",
        description: error instanceof Error 
          ? error.message 
          : "Não foi possível deletar a semente",
        variant: "destructive",
      });
    }
  };

  return (
    <DashboardLayout title="Registro de Sementes" icon={Sprout}>
      {/* Main Content */}
      <main className="container max-w-4xl mx-auto px-4 py-8 space-y-8">
        {/* Form */}
        <section>
          <SeedForm
            onSubmit={handleSubmit}
            onCancel={handleCancel}
            editingSeed={editingSeed}
          />
        </section>

        {/* Table */}
        <section>
          {loading ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Carregando sementes...</p>
            </div>
          ) : (
            <SeedTable
              seeds={seeds}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onExport={handleExport}
            />
          )}
        </section>
      </main>
    </DashboardLayout>
  );
};

export default SeedRegistry;
