import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { MapPin, Maximize2 } from "lucide-react";

const campos = [
  { id: 1, nome: "Campo 01", producao: "Trigo", tamanho: 24, color: "bg-field-green" },
  { id: 2, nome: "Campo 02", producao: "Milho", tamanho: 18, color: "bg-field-yellow" },
  { id: 3, nome: "Campo 03", producao: "Tomate", tamanho: 10, color: "bg-field-green" },
  { id: 4, nome: "Campo 04", producao: "Soja", tamanho: 35, color: "bg-field-orange" },
];

export default function Campos() {
  return (
    <DashboardLayout>
      <div className="card-elevated p-6 md:p-8 animate-fade-in">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-foreground">Meus Campos</h1>
          <button className="text-sm text-primary font-medium hover:underline">
            + Adicionar Campo
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {campos.map((campo, index) => (
            <div
              key={campo.id}
              className="group cursor-pointer animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Field Preview */}
              <div className={`${campo.color} rounded-2xl h-44 relative overflow-hidden mb-4 transition-transform duration-300 group-hover:scale-[1.02]`}>
                <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/5" />
                <button className="absolute top-4 right-4 w-8 h-8 rounded-full bg-card/80 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <Maximize2 className="w-4 h-4 text-foreground" />
                </button>
              </div>

              {/* Field Info */}
              <div className="space-y-1.5">
                <h3 className="font-bold text-lg text-foreground">{campo.nome}</h3>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span>Produção: <span className="text-foreground font-medium">{campo.producao}</span></span>
                </div>
                <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                  <MapPin className="w-4 h-4" />
                  <span>Tamanho: <span className="text-foreground font-medium">{campo.tamanho} hectares</span></span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
