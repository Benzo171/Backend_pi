import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Package, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

type DeliveryStatus = "em_andamento" | "entregue" | "pendente";

interface Delivery {
  id: string;
  produto: string;
  status: DeliveryStatus;
}

const entregas: Delivery[] = [
  { id: "#001", produto: "Trigo", status: "em_andamento" },
  { id: "#002", produto: "Tomate", status: "entregue" },
  { id: "#003", produto: "Soja", status: "pendente" },
];

const statusConfig: Record<DeliveryStatus, { label: string; className: string }> = {
  em_andamento: {
    label: "Em andamento",
    className: "bg-warning/10 text-warning",
  },
  entregue: {
    label: "Entregue",
    className: "bg-success/10 text-success",
  },
  pendente: {
    label: "Pendente",
    className: "bg-pending/10 text-pending",
  },
};

export default function Entregas() {
  return (
    <DashboardLayout>
      <div className="card-elevated p-6 md:p-8 animate-fade-in">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-foreground">Entregas</h1>
          <button className="text-sm text-primary font-medium hover:underline">
            Ver histórico
          </button>
        </div>

        <div className="space-y-4">
          {entregas.map((entrega, index) => (
            <div
              key={entrega.id}
              className="group bg-card border border-border/50 rounded-2xl p-5 hover:shadow-soft transition-all duration-300 cursor-pointer animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center">
                    <Package className="w-6 h-6 text-muted-foreground" />
                  </div>
                  <div>
                    <h3 className="font-bold text-foreground">Entrega {entrega.id}</h3>
                    <p className="text-sm text-muted-foreground">
                      Produto: <span className="text-foreground">{entrega.produto}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <span
                    className={cn(
                      "px-3 py-1.5 rounded-full text-xs font-semibold",
                      statusConfig[entrega.status].className
                    )}
                  >
                    {statusConfig[entrega.status].label}
                  </span>
                  <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-foreground transition-colors" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
