import { useState, useEffect } from "react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { CalendarIcon, Leaf, Save, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Seed } from "@/types/seed";

interface SeedFormProps {
  onSubmit: (seed: Omit<Seed, "id">) => void;
  onCancel: () => void;
  editingSeed?: Seed | null;
}

export function SeedForm({ onSubmit, onCancel, editingSeed }: SeedFormProps) {
  const [nomePopular, setNomePopular] = useState("");
  const [nomeCientifico, setNomeCientifico] = useState("");
  const [fabricante, setFabricante] = useState("");
  const [dataValidade, setDataValidade] = useState<Date | undefined>();
  const [quantidadeEstoque, setQuantidadeEstoque] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (editingSeed) {
      setErrors({});
      setNomePopular(editingSeed.nomePopular);
      setNomeCientifico(editingSeed.nomeCientifico);
      setFabricante(editingSeed.fabricante);
      setDataValidade(new Date(editingSeed.dataValidade));
      setQuantidadeEstoque(editingSeed.quantidadeEstoque.toString());
    }
  }, [editingSeed]);

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!nomePopular.trim()) {
      newErrors.nomePopular = "Nome popular é obrigatório";
    }
    if (!nomeCientifico.trim()) {
      newErrors.nomeCientifico = "Nome científico é obrigatório";
    }
    if (!fabricante.trim()) {
      newErrors.fabricante = "Fabricante é obrigatório";
    }
    if (!dataValidade) {
      newErrors.dataValidade = "Data de validade é obrigatória";
    } else if (dataValidade.getTime() < new Date().setHours(0, 0, 0, 0)) {
      newErrors.dataValidade = "Data de validade deve ser igual ou posterior a hoje";
    }
    if (!quantidadeEstoque.trim()) {
      newErrors.quantidadeEstoque = "Quantidade é obrigatória";
    } else if (parseInt(quantidadeEstoque) <= 0) {
      newErrors.quantidadeEstoque = "Quantidade deve ser maior que 0";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit({
        nomePopular: nomePopular.trim(),
        nomeCientifico: nomeCientifico.trim(),
        fabricante: fabricante.trim(),
        dataValidade: dataValidade!,
        quantidadeEstoque: parseInt(quantidadeEstoque),
      });
      resetForm();
    }
  };

  const resetForm = () => {
    setNomePopular("");
    setNomeCientifico("");
    setFabricante("");
    setDataValidade(undefined);
    setQuantidadeEstoque("");
    setErrors({});
  };

  const handleCancel = () => {
    resetForm();
    onCancel();
  };

  return (
    <Card className="shadow-soft animate-scale-in border-border/50 overflow-hidden">
      <CardHeader className="gradient-hero pb-6">
        <CardTitle className="flex items-center gap-3 text-primary-foreground text-xl font-semibold">
          <div className="p-2 bg-primary-foreground/20 rounded-lg backdrop-blur-sm">
            <Leaf className="h-5 w-5" />
          </div>
          {editingSeed ? "Editar Semente" : "Cadastro de Sementes"}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid gap-5 md:grid-cols-2">
            {/* Nome Popular */}
            <div className="space-y-2">
              <Label htmlFor="nomePopular" className="text-foreground font-medium">
                Nome Popular
              </Label>
              <Input
                id="nomePopular"
                value={nomePopular}
                onChange={(e) => setNomePopular(e.target.value)}
                placeholder="Ex: Milho amarelo"
                className={cn(
                  "transition-all duration-200 focus:shadow-glow",
                  errors.nomePopular && "border-destructive"
                )}
              />
              {errors.nomePopular && (
                <p className="text-sm text-destructive animate-fade-in">
                  {errors.nomePopular}
                </p>
              )}
            </div>

            {/* Nome Científico */}
            <div className="space-y-2">
              <Label htmlFor="nomeCientifico" className="text-foreground font-medium">
                Nome Científico
              </Label>
              <Input
                id="nomeCientifico"
                value={nomeCientifico}
                onChange={(e) => setNomeCientifico(e.target.value)}
                placeholder="Ex: Zea mays"
                className={cn(
                  "transition-all duration-200 focus:shadow-glow italic",
                  errors.nomeCientifico && "border-destructive"
                )}
              />
              {errors.nomeCientifico && (
                <p className="text-sm text-destructive animate-fade-in">
                  {errors.nomeCientifico}
                </p>
              )}
            </div>

            {/* Fabricante */}
            <div className="space-y-2">
              <Label htmlFor="fabricante" className="text-foreground font-medium">
                Fabricante
              </Label>
              <Input
                id="fabricante"
                value={fabricante}
                onChange={(e) => setFabricante(e.target.value)}
                placeholder="Ex: AgroBrasil Sementes"
                className={cn(
                  "transition-all duration-200 focus:shadow-glow",
                  errors.fabricante && "border-destructive"
                )}
              />
              {errors.fabricante && (
                <p className="text-sm text-destructive animate-fade-in">
                  {errors.fabricante}
                </p>
              )}
            </div>

            {/* Data de Validade */}
            <div className="space-y-2">
              <Label className="text-foreground font-medium">Data de Validade</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal transition-all duration-200",
                      !dataValidade && "text-muted-foreground",
                      errors.dataValidade && "border-destructive"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {dataValidade ? (
                      format(dataValidade, "dd 'de' MMMM 'de' yyyy", { locale: ptBR })
                    ) : (
                      <span>Selecione uma data</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={dataValidade}
                    onSelect={setDataValidade}
                    disabled={(date) => date < new Date().setHours(0, 0, 0, 0)}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
              {errors.dataValidade && (
                <p className="text-sm text-destructive animate-fade-in">
                  {errors.dataValidade}
                </p>
              )}
            </div>

            {/* Quantidade em Estoque */}
            <div className="space-y-2 md:col-span-2 md:max-w-xs">
              <Label htmlFor="quantidadeEstoque" className="text-foreground font-medium">
                Quantidade em Estoque
              </Label>
              <Input
                id="quantidadeEstoque"
                type="number"
                min="1"
                value={quantidadeEstoque}
                onChange={(e) => setQuantidadeEstoque(e.target.value)}
                placeholder="Ex: 1200"
                className={cn(
                  "transition-all duration-200 focus:shadow-glow",
                  errors.quantidadeEstoque && "border-destructive"
                )}
              />
              {errors.quantidadeEstoque && (
                <p className="text-sm text-destructive animate-fade-in">
                  {errors.quantidadeEstoque}
                </p>
              )}
            </div>
          </div>

          {/* Buttons */}
          <div className="flex flex-col-reverse sm:flex-row gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={handleCancel}
              className="sm:flex-1 transition-all duration-200 hover:bg-muted"
            >
              <X className="mr-2 h-4 w-4" />
              Cancelar
            </Button>
            <Button
              type="submit"
              className="sm:flex-1 gradient-hero text-primary-foreground transition-all duration-200 hover:opacity-90 hover:shadow-glow"
            >
              <Save className="mr-2 h-4 w-4" />
              {editingSeed ? "Atualizar" : "Salvar"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
