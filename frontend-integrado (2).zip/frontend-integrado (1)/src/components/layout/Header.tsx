import { Bell, User } from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";

interface HeaderProps {
  showNav?: boolean;
}

const navItems = [
  { label: "Início", path: "/dashboard" },
  { label: "Campos", path: "/campos" },
  { label: "Entregas", path: "/entregas" },
  { label: "Monitoramento", path: "/monitoramento" },
  { label: "Registro de Sementes", path: "/registro-sementes" },
  { label: "Perfil", path: "/perfil" },
];

export function Header({ showNav = true }: HeaderProps) {
  const location = useLocation();

  return (
    <header className="bg-header sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/dashboard" className="flex flex-col leading-tight">
            <span className="text-accent font-bold text-lg tracking-tight">SEED</span>
            <span className="text-header-foreground font-bold text-lg tracking-tight -mt-1">TRAK</span>
          </Link>

          {/* Navigation */}
          {showNav && (
            <nav className="hidden md:flex items-center gap-6">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={cn(
                    "text-sm font-medium transition-colors duration-200",
                    location.pathname === item.path
                      ? "text-header-foreground"
                      : "text-header-foreground/60 hover:text-header-foreground"
                  )}
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          )}

          {/* Actions */}
          {showNav && (
            <div className="flex items-center gap-3">
              <button className="w-10 h-10 rounded-full bg-header-foreground/10 flex items-center justify-center text-header-foreground/80 hover:bg-header-foreground/20 transition-colors">
                <Bell className="w-5 h-5" />
              </button>
              <Link to="/perfil" className="w-10 h-10 rounded-full bg-accent flex items-center justify-center">
                <User className="w-5 h-5 text-accent-foreground" />
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
