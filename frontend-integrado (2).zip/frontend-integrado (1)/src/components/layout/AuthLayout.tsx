import { Link } from "react-router-dom";

interface AuthLayoutProps {
  children: React.ReactNode;
}

export function AuthLayout({ children }: AuthLayoutProps) {
  return (
    <div className="min-h-screen bg-card flex flex-col">
      {/* Logo */}
      <div className="p-6">
        <Link to="/" className="flex flex-col leading-tight">
          <span className="text-accent font-bold text-lg tracking-tight">SEED</span>
          <span className="text-foreground font-bold text-lg tracking-tight -mt-1">TRAK</span>
        </Link>
      </div>

      {/* Content */}
      <div className="flex-1 flex items-center justify-center px-4 pb-16">
        <div className="w-full max-w-md animate-fade-in">
          {children}
        </div>
      </div>
    </div>
  );
}
