import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Edit2, Package, Trash2, Leaf, Calendar, Factory, FlaskConical, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Seed } from "@/types/seed";

interface SeedTableProps {
  seeds: Seed[];
  onEdit: (seed: Seed) => void;
  onDelete: (id: string) => void;
  onExport: () => void;
}

export function SeedTable({ seeds, onEdit, onDelete, onExport }: SeedTableProps) {
  if (seeds.length === 0) {
    return (
      <Card className="shadow-soft animate-fade-in border-border/50">
        <CardContent className="flex flex-col items-center justify-center py-16">
          <div className="p-4 bg-muted rounded-full mb-4">
            <Leaf className="h-8 w-8 text-muted-foreground" />
          </div>
          <p className="text-muted-foreground text-center">
            Nenhuma semente cadastrada.
            <br />
            <span className="text-sm">Adicione sua primeira semente acima.</span>
          </p>
        </CardContent>
      </Card>
    );
  }

  const getDaysUntilExpiry = (date: Date) => {
    const today = new Date();
    const expiryDate = new Date(date);
    const diffTime = expiryDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const getExpiryBadge = (date: Date) => {
    const days = getDaysUntilExpiry(date);
    if (days <= 30) {
      return <Badge variant="destructive">Vence em {days} dias</Badge>;
    }
    if (days <= 90) {
      return <Badge variant="secondary" className="bg-amber-100 text-amber-800 border-amber-200">Vence em {days} dias</Badge>;
    }
    return <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20">Válido</Badge>;
  };

  return (
    <Card className="shadow-soft animate-slide-up border-border/50 overflow-hidden">
      <CardHeader className="bg-secondary/50 border-b border-border/50 flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2 text-lg font-semibold text-foreground">
          <Package className="h-5 w-5 text-primary" />
          Sementes Cadastradas
          <Badge variant="outline" className="ml-2">
            {seeds.length} {seeds.length === 1 ? "item" : "itens"}
          </Badge>
        </CardTitle>
        <Button variant="secondary" size="sm" onClick={onExport}>
          <Download className="mr-2 h-4 w-4" />
          Exportar CSV
        </Button>
      </CardHeader>
      <CardContent className="p-0">
        {/* Desktop Table */}
        <div className="hidden md:block overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/30 hover:bg-muted/30">
                <TableHead className="font-semibold">Nome Popular</TableHead>
                <TableHead className="font-semibold">Nome Científico</TableHead>
                <TableHead className="font-semibold">Fabricante</TableHead>
                <TableHead className="font-semibold">Validade</TableHead>
                <TableHead className="font-semibold text-center">Estoque</TableHead>
                <TableHead className="font-semibold text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {seeds.map((seed, index) => (
                <TableRow
                  key={seed.id}
                  className="group transition-colors hover:bg-muted/50"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <TableCell className="font-medium text-foreground">
                    {seed.nomePopular}
                  </TableCell>
                  <TableCell className="italic text-muted-foreground">
                    {seed.nomeCientifico}
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {seed.fabricante}
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col gap-1">
                      <span className="text-sm text-foreground">
                        {format(new Date(seed.dataValidade), "dd/MM/yyyy", { locale: ptBR })}
                      </span>
                      {getExpiryBadge(seed.dataValidade)}
                    </div>
                  </TableCell>
                  <TableCell className="text-center">
                    <Badge
                      variant="outline"
                      className={
                        seed.quantidadeEstoque < 100
                          ? "border-destructive/50 text-destructive"
                          : "border-primary/50 text-primary"
                      }
                    >
                      {seed.quantidadeEstoque.toLocaleString("pt-BR")} un
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2 opacity-70 group-hover:opacity-100 transition-opacity">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onEdit(seed)}
                        className="h-8 w-8 text-primary hover:text-primary hover:bg-primary/10"
                      >
                        <Edit2 className="h-4 w-4" />
                        <span className="sr-only">Editar</span>
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onDelete(seed.id)}
                        className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                      >
                        <Trash2 className="h-4 w-4" />
                        <span className="sr-only">Excluir</span>
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Mobile Cards */}
        <div className="md:hidden divide-y divide-border">
          {seeds.map((seed, index) => (
            <div
              key={seed.id}
              className="p-4 space-y-3 animate-fade-in"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-semibold text-foreground">{seed.nomePopular}</h3>
                  <p className="text-sm italic text-muted-foreground">{seed.nomeCientifico}</p>
                </div>
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onEdit(seed)}
                    className="h-8 w-8 text-primary"
                  >
                    <Edit2 className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onDelete(seed.id)}
                    className="h-8 w-8 text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Factory className="h-4 w-4" />
                  <span>{seed.fabricante}</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Calendar className="h-4 w-4" />
                  <span>{format(new Date(seed.dataValidade), "dd/MM/yyyy")}</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                {getExpiryBadge(seed.dataValidade)}
                <Badge variant="outline" className="border-primary/50 text-primary">
                  {seed.quantidadeEstoque.toLocaleString("pt-BR")} unidades
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
