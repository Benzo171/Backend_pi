// Configuração da API
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8080';

export const API_ENDPOINTS = {
  auth: {
    login: `${API_BASE_URL}/api/auth/login`,
  },
  sementes: {
    list: `${API_BASE_URL}/api/sementes`,
    create: `${API_BASE_URL}/api/sementes`,
    update: (id: number) => `${API_BASE_URL}/api/sementes/${id}`,
    delete: (id: number) => `${API_BASE_URL}/api/sementes/${id}`,
    getById: (id: number) => `${API_BASE_URL}/api/sementes/${id}`,
  },
};

// Função auxiliar para fazer requisições
export async function apiRequest<T>(
  url: string,
  options?: RequestInit
): Promise<T> {
  const response = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
    ...options,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.mensagem || `API error: ${response.status}`);
  }

  return response.json();
}
