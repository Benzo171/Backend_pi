import { API_ENDPOINTS, apiRequest } from '@/lib/api';

export interface LoginRequest {
  username: string;
  senha: string;
}

export interface LoginResponse {
  sucesso: boolean;
  mensagem: string;
}

export const authService = {
  async login(username: string, senha: string): Promise<LoginResponse> {
    const response = await apiRequest<LoginResponse>(
      API_ENDPOINTS.auth.login,
      {
        method: 'POST',
        body: JSON.stringify({
          username,
          senha,
        } as LoginRequest),
      }
    );
    
    if (response.sucesso) {
      // Armazenar token/sessão se necessário
      localStorage.setItem('user', JSON.stringify({ username }));
    }
    
    return response;
  },

  logout(): void {
    localStorage.removeItem('user');
  },

  isAuthenticated(): boolean {
    return !!localStorage.getItem('user');
  },

  getUser(): { username: string } | null {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  },
};
