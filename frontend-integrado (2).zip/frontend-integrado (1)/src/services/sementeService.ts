import { API_ENDPOINTS, apiRequest } from '@/lib/api';
import { Seed } from '@/types/seed';

export interface SementeDTO {
  id?: number;
  nomePopular: string;
  nomeCientifico: string;
  fabricante: string;
  dataValidade: string; // ISO date format (YYYY-MM-DD)
  quantidadeEstoque: number;
}

export const sementeService = {
  async listar(): Promise<SementeDTO[]> {
    return apiRequest<SementeDTO[]>(API_ENDPOINTS.sementes.list, {
      method: 'GET',
    });
  },

  async buscarPorId(id: number): Promise<SementeDTO> {
    return apiRequest<SementeDTO>(API_ENDPOINTS.sementes.getById(id), {
      method: 'GET',
    });
  },

  async criar(semente: Omit<SementeDTO, 'id'>): Promise<SementeDTO> {
    return apiRequest<SementeDTO>(API_ENDPOINTS.sementes.create, {
      method: 'POST',
      body: JSON.stringify(semente),
    });
  },

  async atualizar(id: number, semente: Omit<SementeDTO, 'id'>): Promise<SementeDTO> {
    return apiRequest<SementeDTO>(API_ENDPOINTS.sementes.update(id), {
      method: 'PUT',
      body: JSON.stringify(semente),
    });
  },

  async deletar(id: number): Promise<void> {
    await apiRequest<void>(API_ENDPOINTS.sementes.delete(id), {
      method: 'DELETE',
    });
  },

  // Converter Seed (frontend) para SementeDTO (backend)
  seedToDTO(seed: Omit<Seed, 'id'>): Omit<SementeDTO, 'id'> {
    const date = seed.dataValidade instanceof Date 
      ? seed.dataValidade 
      : new Date(seed.dataValidade);
    
    return {
      nomePopular: seed.nomePopular,
      nomeCientifico: seed.nomeCientifico,
      fabricante: seed.fabricante,
      dataValidade: date.toISOString().split('T')[0], // Formato YYYY-MM-DD
      quantidadeEstoque: seed.quantidadeEstoque,
    };
  },

  // Converter SementeDTO (backend) para Seed (frontend)
  dtoToSeed(dto: SementeDTO): Seed {
    return {
      id: String(dto.id),
      nomePopular: dto.nomePopular,
      nomeCientifico: dto.nomeCientifico,
      fabricante: dto.fabricante,
      dataValidade: new Date(dto.dataValidade),
      quantidadeEstoque: dto.quantidadeEstoque,
    };
  },
};
